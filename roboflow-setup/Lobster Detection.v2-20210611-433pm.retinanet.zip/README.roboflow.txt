
Lobster Detection - v2 20210611 433pm
==============================

This dataset was exported via roboflow.ai on June 11, 2021 at 8:20 PM GMT

It includes 1003 images.
Lobsters are annotated in retinanet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit within)

No image augmentation techniques were applied.


